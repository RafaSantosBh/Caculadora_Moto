package com.example.aulasegunda

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var btn8 = findViewById<Button>(R.id.btn8)
        var btn9 = findViewById<Button>(R.id.btn9)
        var btn7 = findViewById<Button>(R.id.btn7)
        var btn6 = findViewById<Button>(R.id.btn6)
        var btn5 = findViewById<Button>(R.id.btn5)
        var btn4 = findViewById<Button>(R.id.btn4)
        var btn3 = findViewById<Button>(R.id.btn3)
        var btn2 = findViewById<Button>(R.id.btn2)
        var btn1 = findViewById<Button>(R.id.btn1)
        var btn0 = findViewById<Button>(R.id.btn0)



        var result = findViewById<TextView>(R.id.result)

        btn8.setOnClickListener {
            result.text = "8"
        }

        btn9.setOnClickListener {
            result.text = "9"
        }

        btn7.setOnClickListener {
            result.text = "7"
        }

        btn6.setOnClickListener {
            result.text = "6"
        }

        btn5.setOnClickListener {
            result.text = "5"
        }

        btn4.setOnClickListener {
            result.text = "4"
        }

        btn3.setOnClickListener {
            result.text = "3"
        }

        btn2.setOnClickListener {
            result.text = "2"
        }

        btn1.setOnClickListener {
            result.text = "1"
        }

        btn0.setOnClickListener {
            result.text = "0"
        }


    }
}